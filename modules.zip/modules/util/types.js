// Copyright 2018-2022 the Deno authors. All rights reserved. MIT license.
import * as types from "../internal/util/types.js";
export * from "../internal/util/types.js";

export default { ...types };